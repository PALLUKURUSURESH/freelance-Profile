import React from "react";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faInstagram, faFacebook, faFacebookMessenger, faLinkedin, faTwitter } from "@fortawesome/free-brands-svg-icons";

import {Link} from "react-router-dom"
import logo from './images/logo1.png'

import './index.css'

const Menu =()=>{
    return(
        <div className="menu-container">
          <Link to="/"> <img src={logo} alt="logo" className="img"/> </Link> 
            <ul className="list-container">
               <Link to="/"> <li >Home</li> </Link>
               <Link to="/about"> <li >About</li> </Link>
               <Link to="/contact"> <li >Contacts</li> </Link>
               <Link to="/services"> <li >Services</li> </Link>
               <Link to="/reviews"> <li >Review</li> </Link>
            </ul>
            <div className="list-icon">
            
            {/* <h1>About Component</h1> */}
            <FontAwesomeIcon icon={faInstagram} className="icon" />
            <FontAwesomeIcon icon={faLinkedin} className="icon" />
            <FontAwesomeIcon icon={faTwitter} className="icon" />
            <FontAwesomeIcon icon={faFacebook} className="icon" />
            <FontAwesomeIcon icon={faFacebookMessenger}className="icon" />
            {/* <FontAwesomeIcon icon={solidPhone} /> */}
        
            </div>
        </div>
    )
}

export default Menu;