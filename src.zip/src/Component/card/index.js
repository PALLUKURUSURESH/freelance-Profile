import React from "react";
import './index.css'

const Card=(props)=>{
    const {details}=props
    const {name,content,image}=details
    return(
        <div className="card-container">
            <div className="card" >

                <img src={image} alt="lo" className="img-1" />

                <div className="poster" >
                    <h1 className="h1">{name}</h1>
                    <p className="p">{content}</p>
                </div>
            </div>
        </div>
    )
}

export default Card