import { Component } from "react";
import background from "./images/hero-bg.jpg"

import './index.css'


const services=[
    {name:"Web Developer"},
    {name:"Content Creator"},
    {name:"UI/Ux Designer"},
    {name:"Graphic Designer"},
    {name:"freelancer"},
]

class Home extends Component{

    state={
        work:services[0].name,
    }
    
    componentDidMount() {
        this.timerId = setInterval(() => {
            this.setState(prevState => {
                const currentIndex = services.findIndex(service => service.name === prevState.work);
                const nextIndex = (currentIndex + 1) % services.length;
                return { work: services[nextIndex].name };
            });
        }, 1000);
    }
    
   
    componentWillUnmount(){
        clearInterval(this.timerId)
        console.log("clear Interval")
    }

    render(){
        const {work}=this.state

        return(
            <div className="container" style={{backgroundImage:`url(${background})`}}>
                
                <p className="caption">I am Alex Smith</p>
                <p className="text">{work}</p>

            </div>
        )
    }
}

export default Home