import React from "react";

import found from './images/notfound1.png'
import './index.css'

const NotFound=()=>{
    return(
       <div className="div-container" >
        
        <p className="text">This site can’t be reached unexpectedly closed the connection.
<br/>
ERR_CONNECTION_CLOSED
</p>
        <img src={found} alt="NotFound"/>
        
        </div>
    )
}
export default NotFound