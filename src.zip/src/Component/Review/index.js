import React from "react";
import { Component } from "react";
import Comments from "../comment";
import './index.css'

const commentList=[
    {
        id:1,
        name:"Suresh",
        comment:"i want a webpage for my blog channel i convey my requirements then alex make my website with low cost now i am happy.",
    },
    {
        id:2,
        name:"Jagadeesh",
        comment:"he gives a awesome website for me.So I recommended him.",
    },
    {
        id:3,
        name:"Indu",
        comment:"Now I am happy with the output he doing very well his work defenetly worth it so I give out 5/4.6 rating for him for this work.",
    }
]





class Review extends Component{

 state={
    id:4,
    name:"",
    comment:"",
    updatedList:commentList,
 }

 addContact=(event)=>{
    event.preventDefault()

    const {name,comment,id}=this.state
    
    this.setState(
        (prevState)=>(
            {id:prevState.id+1}
        )
    )

    const goodLike={
        id,
        name,
        comment,
    }
    console.log(goodLike)
    

    this.setState(
        prevState=>(
            {updatedList:[...prevState.updatedList,goodLike],
             name:"",
             comment:"",
            }
            

        )
    )

}
    
 Username=(event)=>{
     this.setState({name:event.target.value})
 }

 Usercomment=(event)=>{
    this.setState({comment:event.target.value})
}

rnderItem=()=>{
    const {name,comment,updatedList}=this.state;
    if(name!=" " && comment!=" "){
       return(
        updatedList.map((each)=>(
            <Comments details={each} key={each.id}/>
        ))

       ) 
    }
    
}

    render(){
        const {name,comment}=this.state
        return(
            <div className="review-container">
                <h1>Write a Review</h1>
             <form className="card-review" onSubmit={this.addContact}>
                <div>
                <label htmlFor="name"><b>Name:</b></label>
                <input type="text"  className="input-box" onChange={this.Username} name="name" id="name" value={name}/>
                </div>
                <textarea cols={30} rows={10} className="input1-box" placeholder="Write your comment here..." onChange={this.Usercomment} value={comment}></textarea>
                <button className="btn-add" type="submit" > ADD </button>
             </form>

             {/* comment */}
             <h1>Comments</h1>
             <ul>
             {
                this.rnderItem()
             }
             </ul>
             
            </div>
            

       
        )
    }
}

export default Review