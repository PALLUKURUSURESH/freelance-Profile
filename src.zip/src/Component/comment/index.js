import React from "react";

import './index.css'

const Comments=(props)=>{
    const {details}=props
    const {name,comment}=details
    return(
       <div>
             <li className="comment-item">
                <h2>{name}</h2>
                <hr/>
                <p>{comment}</p>
             </li>
       </div>
    )
}

export default Comments