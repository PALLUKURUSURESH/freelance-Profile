import React from "react";
import Card from '../card'

import profile from './images/profile-img.jpg'

import './index.css'


const details=[
    {
        id:1,
        name:"Web Design",
        image:"https://img.freepik.com/premium-photo/concept-assembling-web-page-from-modules-that-fly-around-display-web-design-studio-concept-page-is-display_176814-1839.jpg?size=626&ext=jpg&ga=GA1.1.184889945.1702111366&semt=ais",
        content:"A web designer is responsible for creating the design and layout of a website or web pages.Unlike web developers, who specialise in creating new websites' structures and the code that forms these, web designers tend to focus on the visual aspects of a site, such as its layout and its usability."
    },
    {
        id:2,
        name:"Content Writer",
        image:"https://img.freepik.com/free-vector/online-document-concept-illustration_114360-5453.jpg?size=626&ext=jpg&ga=GA1.1.184889945.1702111366&semt=ais",
        content:"A content writer is a specialist who writes informative and engaging content to improve a brand's visibility. They publish their content on digital platforms and in print, showcasing the brand's products. Content writers produce well-researched content materials, such as blogs, articles, emails, and social media posts."
    },
    {
        id:3,
        name:"UI/UX Designer",
        image:"https://img.freepik.com/free-vector/gradient-ui-ux-background_23-2149051555.jpg?w=996&t=st=1702112239~exp=1702112839~hmac=39edc5d9d050dc29af18c85bb51122605b7a1213d79e4a6ad2247f89edb63ed7",
        content:"A UI/UX Designer's responsibilities include gathering user requirements, designing graphic elements, and developing navigation components. Therefore, you should have prior experience with design software and wireframe tools to be successful in this role."
    }
]

const About = () => {
    return (
        <div className="about-container">
            <h1 className="heading">About</h1>
            <div className="main-content">
                <ul className="ul-container">
                    <li><spam className="none">Name : </spam> Alex-Smith</li>
                    <li><spam className="none">profession :</spam> Freelancer</li>
                    <li><spam className="none">Place :</spam> Los Angeles CA</li>
                    <li><spam className="none">Bio :</spam> Hello, I'm Alex Smith, a dedicated and versatile freelancer with a passion for turning ideas into reality. With a background in Graphic Designer, I bring 6+ years of experience to the table. My work is fueled by creativity, attention to detail, and a commitment to delivering high-quality results.</li>
                    <li><spam className="none">services :</spam> I offer a range of freelance services, including graphic desinging. Whether you need video Editing, Ui/UX Design, or Web Design , I have the expertise to meet your needs.</li>
                </ul>
                <img src={profile}  alt="Profile" className="image"/>
            </div>



            <div className="second-content">
                <div className="part-1">
                    <h1>Experiences</h1>
                    <p>Jack : Working with Alex was a pleasure. Their attention to detail and creative flair exceeded our expectations. We look forward to future collaborations.</p>
                    <p>Smith : Alex's professionalism and timely delivery were impressive. I highly recommend their services.</p>
                </div>
                <div className="part-2">
                    <h1>Skills</h1>
                <div className="left-side">
                    <div className="module-1">
                        <h2>KNOWLEDGE</h2>
                            <ul>
                                <li>HTML</li>
                                <li>CSS</li>
                                <li>JAVASCRIPT</li>
                                <li>SEO</li>
                                <li>REACT</li>
                                <li>BACKEND</li>
                            </ul>
                    </div>
                    <div className="module-2">
                        <h2>TOOLS</h2>
                        <ul>
                            <li>PhotoShop</li>
                            <li>Final cut Pro</li>
                            <li>Premium Pro</li>
                        </ul>
                    </div>
                </div>
                </div>
            </div>
            <h1 className="heading">Services</h1>
        <div className="cards">
        {
            details.map(each=>(
                <Card details={each} keys={each.id} />
            ))
        }
        </div>
         
            
        </div>
    )
}

export default About;
